<a href="https://freecodecamp.com/"><img align="right" width="160" src="/logos/freecodecamp.png"></img></a>

# Java, C# Programming Languages

<br>

## Java Programming Language

<table>
    <thead>
        <tr>
<th width="25px">#</th>
<th width="1200px">Course Name</th>
<th width="25px">Hrs</th>
        </tr>
    </thead>
    <tbody>
            <tr>
<td align="center">01</td>
<td align="left"><a href="https://youtube.com/watch?v=pyXnX2SEaFc">Java Native Interface (28-Hour Course)</a></td>
<td align="center">14</td>
            </tr>
            <tr>
<td align="center">02</td>
<td align="left"><a href="https://youtube.com/watch?v=7WiJGTPuVeU">Java Beginner Course - Get Started Coding with Java!</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">03</td>
<td align="left"><a href="https://youtube.com/watch?v=rPSL1alFIjI">Functional Programming in Java - Full Course</a></td>
<td align="center">3</td>
            </tr>
            <tr>
<td align="center">04</td>
<td align="left"><a href="https://youtube.com/watch?v=A74TOX803D0">Java Programming for Beginners – Full Course</a></td>
<td align="center">5</td>
            </tr>
            <tr>
<td align="center">05</td>
<td align="left"><a href="https://youtube.com/watch?v=GdzRzWymT4c">Java Basics – Crash Course</a></td>
<td align="center">4</td>
            </tr>
            <tr>
<td align="center">06</td>
<td align="left"><a href="https://youtube.com/watch?v=grEKMHGYyns">Learn Java 8 - Full Tutorial for Beginners</a></td>
<td align="center">20</td>
            </tr>
            <tr>
<td align="center">07</td>
<td align="left"><a href="https://youtube.com/watch?v=GoXwIVyNvX0">Intro to Java Programming - Course for Absolute Beginners</a></td>
<td align="center">4</td>
            </tr>
    </tbody>
</table>

## C# Programming Language

<table>
    <thead>
        <tr>
<th width="25px">#</th>
<th width="1200px">Course Name</th>
<th width="25px">Hrs</th>
        </tr>
    </thead>
    <tbody>
            <tr>
<td align="center">01</td>
<td align="left"><a href="https://youtube.com/watch?v=__izua1kKeI">Learn How to Code - Programming for Beginners Tutorial with Python and C#</a></td>
<td align="center">5</td>
            </tr>
            <tr>
<td align="center">02</td>
<td align="left"><a href="https://youtube.com/watch?v=6GQAE7iLOhY">Free Foundational C# Certification from Microsoft – Full Course</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">03</td>
<td align="left"><a href="https://youtube.com/watch?v=GhQdlIFylQ8">C# Tutorial - Full Course for Beginners</a></td>
<td align="center">5</td>
            </tr>
            <tr>
<td align="center">04</td>
<td align="left"><a href="https://youtube.com/watch?v=WnMQ8HlmeXc">UML Diagrams Full Course (Unified Modeling Language)</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">05</td>
<td align="left"><a href="https://youtube.com/watch?v=wfWxdh-_k_4">Create a C# Application from Start to Finish - Complete Course</a></td>
<td align="center">24</td>
            </tr>
    </tbody>
</table>
