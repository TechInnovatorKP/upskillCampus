<a href="https://freecodecamp.com/"><img align="right" width="160" src="/logos/freecodecamp.png"></img></a>

# Fundamentals of Computer Science

<br>

## Fundamentals of Computer Science

<table>
    <thead>
        <tr>
<th width="25px">#</th>
<th width="1200px">Course Name</th>
<th width="25px">Hrs</th>
        </tr>
    </thead>
    <tbody>
            <tr>
<td align="center">01</td>
<td align="left"><a href="https://youtube.com/watch?v=LfaMVlDaQ24">Harvard CS50 (2023) – Full Computer Science University Course</a></td>
<td align="center">25</td>
            </tr>
            <tr>
<td align="center">02</td>
<td align="left"><a href="https://youtube.com/watch?v=MIL2BK02X8A">Pointers in C for Absolute Beginners – Full Course</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">03</td>
<td align="left"><a href="https://youtube.com/watch?v=8mAITcNt710">Harvard CS50 – Full Computer Science University Course</a></td>
<td align="center">25</td>
            </tr>
            <tr>
<td align="center">04</td>
<td align="left"><a href="https://youtube.com/watch?v=F0WoVEr0-44">Computational Thinking & Scratch - Intro to Computer Science - Harvard's CS50 (2018)</a></td>
<td align="center">1</td>
            </tr>
            <tr>
<td align="center">05</td>
<td align="left"><a href="https://youtube.com/watch?v=2SpuBqvNjHI">Maths for Programmers Tutorial - Full Course on Sets and Logic</a></td>
<td align="center">1</td>
            </tr>
            <tr>
<td align="center">06</td>
<td align="left"><a href="https://youtube.com/watch?v=pejxLkT-wek">Memory - Intro to Computer Science - Harvard's CS50 (2018)</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">07</td>
<td align="left"><a href="https://youtube.com/watch?v=y2kg3MOk1sY">Computer & Technology Basics Course for Absolute Beginners</a></td>
<td align="center">1</td>
            </tr>
            <tr>
<td align="center">08</td>
<td align="left"><a href="https://youtube.com/watch?v=UTQp6mvhb0Y">Visual Studio Code Full Course - VS Code for Beginners</a></td>
<td align="center">5</td>
            </tr>
            <tr>
<td align="center">09</td>
<td align="left"><a href="https://youtube.com/watch?v=g1vy03ZY5mM">Visual Studio Code Extensions to Improve Your Productivity</a></td>
<td align="center">1</td>
            </tr>
            <tr>
<td align="center">10</td>
<td align="left"><a href="https://youtube.com/watch?v=zOjov-2OZ0E">Introduction to Programming and Computer Science - Full Course</a></td>
<td align="center">2</td>
            </tr>
            <tr>
<td align="center">11</td>
<td align="left"><a href="https://youtube.com/watch?v=heXQnM99oAI">VS Code Tutorial – Become More Productive</a></td>
<td align="center">6</td>
            </tr>
    </tbody>
</table>

## Mathematics for Computer Science

<table>
    <thead>
        <tr>
<th width="25px">#</th>
<th width="1200px">Course Name</th>
<th width="25px">Hrs</th>
        </tr>
    </thead>
    <tbody>
            <tr>
<td align="center">01</td>
<td align="left"><a href="https://youtube.com/watch?v=eI4an8aSsgw">Precalculus Course</a></td>
<td align="center">6</td>
            </tr>
            <tr>
<td align="center">02</td>
<td align="left"><a href="https://youtube.com/watch?v=HfACrKJ_Y2w">Calculus 1 - Full College Course</a></td>
<td align="center">12</td>
            </tr>
            <tr>
<td align="center">03</td>
<td align="left"><a href="https://youtube.com/watch?v=7gigNsz4Oe8">Calculus 2 - Full College Course</a></td>
<td align="center">7</td>
            </tr>
            <tr>
<td align="center">04</td>
<td align="left"><a href="https://youtube.com/watch?v=JnTa9XtvmfI">Linear Algebra - Full College Course</a></td>
<td align="center">12</td>
            </tr>
    </tbody>
</table>
