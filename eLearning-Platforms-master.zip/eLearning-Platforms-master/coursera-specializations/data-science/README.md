<a href="https://youtube.com/"><img align="right" width="160" src="/logos/coursera.png"></img></a>

# Data Science Specializations

<br><br>

<br>
<a href="/coursera-specializations/data-science/data-analysis-and-visualization.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-analytics.png"></img></a>
<a href="/coursera-specializations/data-science/data-analysis-and-visualization.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-visualization.png"></img></a>
<a href="/coursera-specializations/data-science/data-analysis-and-visualization.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-analysis.png"></img></a>
<br>

## [Data Analysis and Visualization](/coursera-specializations/data-science/data-analysis-and-visualization.md) Specializations

<br>
<a href="/coursera-specializations/data-science/data-science-and-business-analytics.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/business-analytics.png"></img></a>
<a href="/coursera-specializations/data-science/data-science-and-business-analytics.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/computer-modeling.png"></img></a>
<a href="/coursera-specializations/data-science/data-science-and-business-analytics.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-science.png"></img></a>
<br>

## [Data Science and Business Analytics](/coursera-specializations/data-science/data-science-and-business-analytics.md) Specializations

<br>
<a href="/coursera-specializations/data-science/business-intelligence-and-data-management.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/business-intelligence.png"></img></a>
<a href="/coursera-specializations/data-science/business-intelligence-and-data-management.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-management.png"></img></a>
<a href="/coursera-specializations/data-science/business-intelligence-and-data-management.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-modeling.png"></img></a>
<br>

## [Business Intelligence and Data Management](/coursera-specializations/data-science/business-intelligence-and-data-management.md) Specializations

<br>
<a href="/coursera-specializations/data-science/continuous-delivery-and-mlops.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/cloud-computing.png"></img></a>
<a href="/coursera-specializations/data-science/continuous-delivery-and-mlops.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/mlops.png"></img></a>
<a href="/coursera-specializations/data-science/continuous-delivery-and-mlops.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/systems-development-methodologies.png"></img></a>
<br>

## [Continuous Delivery and MLOps](/coursera-specializations/data-science/continuous-delivery-and-mlops.md) Specializations

<br>
<a href="/coursera-specializations/data-science/data-engineering.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/cloud-database.png"></img></a>
<a href="/coursera-specializations/data-science/data-engineering.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-governance.png"></img></a>
<a href="/coursera-specializations/data-science/data-engineering.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-engineering.png"></img></a>
<br>

## [Data Engineering](/coursera-specializations/data-science/data-engineering.md) Specializations

<br>
<a href="/coursera-specializations/data-science/big-data-analytics-and-modeling.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/database-systems.png"></img></a>
<a href="/coursera-specializations/data-science/big-data-analytics-and-modeling.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/big-data-modeling.png"></img></a>
<a href="/coursera-specializations/data-science/big-data-analytics-and-modeling.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/big-data-analytics.png"></img></a>
<br>

## [Big Data Analytics and Modeling](/coursera-specializations/data-science/big-data-analytics-and-modeling.md) Specializations
