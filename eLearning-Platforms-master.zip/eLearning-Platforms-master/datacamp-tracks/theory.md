<a href="https://datacamp.com/"><img align="right" width="160" src="/logos/datacamp.png"></img></a>

# Theory Tracks

## Skills Tracks

<table>
    <thead>
        <tr>
<th width="25px">#</th>
<th width="250px">Skill Tracks</th>
<th width="900px">Courses</th>
<th width="25px">Hrs</th>
        </tr>
    </thead>
    <tbody>
            <tr>
                <td rowspan=5 align="center">01</td>
                <td rowspan=5 align="center">
<a href="https://app.datacamp.com/learn/skill-tracks/understanding-data-topics">Understanding Data Topics</a><br>
                </td>
                <td><a href="https://app.datacamp.com/learn/courses/understanding-data-science">Understanding Data Science</a></td>
                <td rowspan=5 align="center">10</td>
            </tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/understanding-machine-learning">Understanding Machine Learning</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/understanding-data-visualization">Understanding Data Visualization</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/understanding-data-engineering">Understanding Data Engineering</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/understanding-cloud-computing">Understanding Cloud Computing</a></td></tr>
    </tbody>
    <tbody>
            <tr>
                <td rowspan=7 align="center">04</td>
                <td rowspan=7 align="center">
<a href="https://app.datacamp.com/learn/skill-tracks/foundational-data-skills-for-business-leaders">Data Skills for Business</a><br>
                </td>
                <td><a href="https://app.datacamp.com/learn/courses/data-science-for-business">Data Science for Business</a></td>
                <td rowspan=7 align="center">20</td>
            </tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/introduction-to-statistics-in-spreadsheets">Introduction to Statistics in Spreadsheets</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/machine-learning-for-business">Machine Learning for Business</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/data-driven-decision-making-for-business">Data-Driven Decision Making for Business</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/marketing-analytics-for-business">Marketing Analytics for Business</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/ai-fundamentals">AI Fundamentals</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/introduction-to-data-science-in-python">Introduction to Data Science in Python</a></td></tr>
    </tbody>
    <tbody>
            <tr>
                <td rowspan=5 align="center">03</td>
                <td rowspan=5 align="center">
<a href="https://app.datacamp.com/learn/skill-tracks/data-literacy-professional">Data Literacy Professional</a><br>
                </td>
                <td><a href="https://app.datacamp.com/learn/courses/introduction-to-data">Introduction to Data</a></td>
                <td rowspan=5 align="center">12</td>
            </tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/communicating-data-insights">Communicating Data Insights</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/introduction-to-data-literacy">Introduction to Data Literacy</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/introduction-to-statistics">Introduction to Statistics</a></td></tr>
            <tr><td><a href="https://app.datacamp.com/learn/courses/data-storytelling-concepts">Data Storytelling Concepts</a></td></tr>
    </tbody>
</table>
