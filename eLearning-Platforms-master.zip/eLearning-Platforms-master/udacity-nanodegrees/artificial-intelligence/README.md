<a href="https://udacity.com/"><img align="right" width="160" src="/logos/udacity.png"></img></a>

# Artificial Intelligence Nanodegrees

<br><br>

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/artificial-intelligence-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/computational-cognitive-science.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/artificial-intelligence-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/soft-computing.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/artificial-intelligence-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/artificial-intelligence.png"></img></a>
<br>

## [Artificial Intelligence Algorithms](/udacity-nanodegrees/artificial-intelligence/artificial-intelligence-algorithms.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/machine-learning-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/unsupervised-learning.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/machine-learning-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/supervised-learning.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/machine-learning-algorithms.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/machine-learning.png"></img></a>
<br>

## [Machine Learning Algorithms](/udacity-nanodegrees/artificial-intelligence/machine-learning-algorithms.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/neural-networks-and-deep-learning.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/generative-adversarial-network.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/neural-networks-and-deep-learning.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/deep-learning.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/neural-networks-and-deep-learning.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/neural-networks.png"></img></a>
<br>

## [Neural Networks and Deep Learning](/udacity-nanodegrees/artificial-intelligence/neural-networks-and-deep-learning.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/intelligent-automation.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/cognitive-automation.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/intelligent-automation.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/robotics-process-automation.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/intelligent-automation.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/process-mining.png"></img></a>
<br>

## [Intelligent Automation](/udacity-nanodegrees/artificial-intelligence/intelligent-automation.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/signal-processing-and-data-compression.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/differential-equations.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/signal-processing-and-data-compression.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/signal-processing.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/signal-processing-and-data-compression.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-compression.png"></img></a>
<br>

## [Signal Processing and Data Compression](/udacity-nanodegrees/artificial-intelligence/signal-processing-and-data-compression.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/image-processing-and-computer-vision.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/pattern-recognition.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/image-processing-and-computer-vision.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/computer-vision.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/image-processing-and-computer-vision.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/image-processing.png"></img></a>
<br>

## [Image Processing and Computer Vision](/udacity-nanodegrees/artificial-intelligence/image-processing-and-computer-vision.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/natural-language-processing-and-text-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/text-mining.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/natural-language-processing-and-text-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/natural-language-processing.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/natural-language-processing-and-text-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/data-mining.png"></img></a>
<br>

## [Natural Language Processing and Text Mining](/udacity-nanodegrees/artificial-intelligence/natural-language-processing-and-text-mining.md) Nanodegrees

<br>
<a href="/udacity-nanodegrees/artificial-intelligence/advanced-multimedia-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/speech-processing.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/advanced-multimedia-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/machine-vision.png"></img></a>
<a href="/udacity-nanodegrees/artificial-intelligence/advanced-multimedia-mining.md"><img align="right" width="80" src="https://github.com/cs-MohamedAyman/cs-MohamedAyman/blob/master/logos/multimedia-mining.png"></img></a>
<br>

## [Advanced Multimedia Mining](/udacity-nanodegrees/artificial-intelligence/advanced-multimedia-mining.md) Nanodegrees
