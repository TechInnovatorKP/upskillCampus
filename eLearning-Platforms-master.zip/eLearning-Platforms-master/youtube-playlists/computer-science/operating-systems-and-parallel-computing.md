<img align="right" width="100" src="/logos/youtube.png"></img>

## Operating Systems and Parallel Computing Playlists

<h3>-  Operating Systems</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">Tutorials Point (India) Ltd.</td>
            <td><a href="https://youtube.com/playlist?list=PLWPirh4EWFpGkHH9JTKH9KsnfAA471Fhy">Operating System</a></td>
            <td align="center">93</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Neso Academy</td>
            <td><a href="https://youtube.com/playlist?list=PLBlnK6fEyqRiVhbXDGLXDk_OQAeuVcp2O">Operating System</a></td>
            <td align="center">58</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Lectures by Ravindrababu Ravula</td>
            <td><a href="https://youtube.com/playlist?list=PLEbnTDJUr_If_BnzJkkN_J0Tl3iXTL8vq">Operating Systems</a></td>
            <td align="center">34</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">KNOWLEDGE GATE</td>
            <td><a href="https://youtube.com/playlist?list=PLmXKhU9FNesSFvj6gASuWmQd23Ul5omtD">OPERATING SYSTEM OS IN HINDI</a></td>
            <td align="center">144</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Easy Engineering Classes</td>
            <td><a href="https://youtube.com/playlist?list=PLV8vIYTIdSnZ67NQObdXE0gFjrzPrNKHp">Operating System</a></td>
            <td align="center">65</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPkKfusBLVfklgfdcB3BNpwX">Advanced Operating Systems Part 1 of 4</a></td>
            <td align="center">149</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPm4vV1XbFV93ZuT2saSq1hO">Advanced Operating Systems Part 2 of 4</a></td>
            <td align="center">150</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPk5-YaXFkWY4UXdv6pVdiYg">Advanced Operating Systems Part 3 of 4</a></td>
            <td align="center">131</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPmfaiuzJcK3tNoeKlvRR990">Advanced Operating Systems Part 4 of 4</a></td>
            <td align="center">119</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Smashers</td>
            <td><a href="https://youtube.com/playlist?list=PLxCzCOWd7aiGz9donHRrE9I3Mwn6XdP8p">Operating System</a></td>
            <td align="center">85</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Education 4u</td>
            <td><a href="https://youtube.com/playlist?list=PLrjkTql3jnm9U1tSPnPQWQGIGNkUwBFv-">Operating Systems</a></td>
            <td align="center">75</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Jenny's lectures CS/IT NET&JRF</td>
            <td><a href="https://youtube.com/playlist?list=PLdo5W4Nhv31a5ucW_S1K3-x6ztBRD-Pna">Operating Systems</a></td>
            <td align="center">31</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">LearnEveryone</td>
            <td><a href="https://youtube.com/playlist?list=PL9P1J9q3_9fNDbAvZoEwNbxNUlIJM-n0n">OPERATING SYSTEM HINDI CONCEPTS</a></td>
            <td align="center">100</td>
            <td align="center">35</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">LearnEveryone</td>
            <td><a href="https://youtube.com/playlist?list=PL9P1J9q3_9fOTGzsBCn0T2T5vHLdBcDq_">OPERATING SYSTEM CONCEPTS</a></td>
            <td align="center">97</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">5 Minutes Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLYwpaL_SFmcANxMtSMQvD3DizZq_DLyrV">System Programming And Operating System (SPOS)</a></td>
            <td align="center">62</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">5 Minutes Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLYwpaL_SFmcD0LLrv7CXxSiO2gNJsoxpi">Operating System</a></td>
            <td align="center">60</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Simple Snippets</td>
            <td><a href="https://youtube.com/playlist?list=PLIY8eNdw5tW_lHyageTADFKBt9weJXndE">CPU Scheduling Algorithms - Operating Systems</a></td>
            <td align="center">7</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Simple Snippets</td>
            <td><a href="https://youtube.com/playlist?list=PLIY8eNdw5tW-BxRY0yK3fYTYVqytw8qhp">Paging & Page Replacement Algorithms - Operating Systems</a></td>
            <td align="center">9</td>
            <td align="center">3</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">saurabhschool</td>
            <td><a href="https://youtube.com/playlist?list=PLTZbNwgO5ebqnympIYe2GX4hjjsS9Psdm">Operating System</a></td>
            <td align="center">27</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">TutorialsSpace- Er. Deepak Garg</td>
            <td><a href="https://youtube.com/playlist?list=PLL8qj6F8dGlSR4SolVHM2W_XtXCQOmu1v">Operating System Tutorials In Hindi By Deepak Garg</a></td>
            <td align="center">146</td>
            <td align="center">50</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Barbara Hecker</td>
            <td><a href="https://youtube.com/playlist?list=PL53FD88B185F9796F">Fall 2011 Operating Systems</a></td>
            <td align="center">10</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">TutorialsSpace- Er. Deepak Garg</td>
            <td><a href="https://youtube.com/playlist?list=PLL8qj6F8dGlSR4SolVHM2W_XtXCQOmu1v">Operating System Tutorials In Hindi By Deepak Garg</a></td>
            <td align="center">146</td>
            <td align="center">40</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">TutorialsSpace- Er. Deepak Garg</td>
            <td><a href="https://youtube.com/playlist?list=PLL8qj6F8dGlSPV_qLnkpjEdM2Z2wRobdr">Operating System Tutorials In HINDI</a></td>
            <td align="center">42</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Focus Group</td>
            <td><a href="https://youtube.com/playlist?list=PL6S4aVVtKUksg8qyiDkUv85BwxfbU8B0x">Operating System Lecture</a></td>
            <td align="center">69</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">TutorialsSpace- Er. Deepak Garg</td>
            <td><a href="https://youtube.com/playlist?list=PLL8qj6F8dGlS4jZxioXYH-sZxdMQdMxYy">Operating System Lectures In Hindi</a></td>
            <td align="center">146</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">kashyap B</td>
            <td><a href="https://youtube.com/playlist?list=PLLDC70psjvq5hIT0kfr1sirNuees0NIbG">Operating Systems by P.K.Biswas Sir</a></td>
            <td align="center">31</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">intrigano</td>
            <td><a href="https://youtube.com/playlist?list=PL2jykFOD1AWY3Ot3HResh50JwdBdjilsq">Operating Systems</a></td>
            <td align="center">103</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">itechnica</td>
            <td><a href="https://youtube.com/playlist?list=PL6aFkLM6Wp-pH-JAE1J94k2jZjwv9ZaBA">Operating Systems</a></td>
            <td align="center">38</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">itechnica</td>
            <td><a href="https://youtube.com/playlist?list=PL6aFkLM6Wp-pH-JAE1J94k2jZjwv9ZaBA">Operating Systems</a></td>
            <td align="center">38</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Write your own Operating System</td>
            <td><a href="https://youtube.com/playlist?list=PLHh55M_Kq4OApWScZyPl5HhgsTJS9MZ6M">Write your own Operating System</a></td>
            <td align="center">34</td>
            <td align="center">30</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Xoviabcs</td>
            <td><a href="https://youtube.com/playlist?list=PLEJxKK7AcSEGPOCFtQTJhOElU44J_Jaun">Operating System: IIT Lectures / Tutorials for GATE</a></td>
            <td align="center">37</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Darshan Institute of Engineering & Technology</td>
            <td><a href="https://youtube.com/playlist?list=PLftJ4X48yC1n1FyWM_snN2YweAEAwMDLY">Operating System</a></td>
            <td align="center">79</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">GATE Applied Course</td>
            <td><a href="https://youtube.com/playlist?list=PLEVDNf7p-wYwYE98Jvh_JYt9g43-AJ-cb">Operating System</a></td>
            <td align="center">13</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Bilkent Online Courses</td>
            <td><a href="https://youtube.com/playlist?list=PLhwVAYxlh5dsX6aOfVMZXS8MwKwBmwVM6">CS-342 Operating Systems</a></td>
            <td align="center">48</td>
            <td align="center">40</td>
        </tr>
    </tbody>
    </table>

<h3>-  Shell Scripting</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">ProgrammingKnowledge</td>
            <td><a href="https://youtube.com/playlist?list=PLS1QulWo1RIYmaxcEqw5JhK3b-6rgdWO_">Shell Scripting Tutorial for Beginners</a></td>
            <td align="center">41</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">HackerSploit</td>
            <td><a href="https://youtube.com/playlist?list=PLBf0hzazHTGMJzHon4YXGscxUvsFpxrZT">Shell Scripting</a></td>
            <td align="center">11</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">The Bad Tutorials</td>
            <td><a href="https://youtube.com/playlist?list=PL7B7FA4E693D8E790">Shell Scripting Tutorials</a></td>
            <td align="center">62</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Tech Arkit</td>
            <td><a href="https://youtube.com/playlist?list=PL8cE5Nxf6M6b8qW7CSMsdKbEsPdG9pWfu">Shell Scripting Tutorial for Beginners</a></td>
            <td align="center">66</td>
            <td align="center">15</td>
        </tr>
    </tbody>
</table>

<h3>-  Parallel Programming</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PLbMVogVj5nJQRvzENlvMKA9q70ScSRZBQ">Computer Science - Parallel Computing</a></td>
            <td align="center">34</td>
            <td align="center">30</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPm0z11jGTXRF7RuEEAgsIwH">Introduction to Parallel Programming</a></td>
            <td align="center">39</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Udacity</td>
            <td><a href="https://youtube.com/playlist?list=PLAwxTw4SYaPnFKojVQrmyOGFCqHTxfdv2">Intro to Parallel Programming</a></td>
            <td align="center">458</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">5 Minutes Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLYwpaL_SFmcB73J5yO6uSFUycHJSA45O0">CUDA</a></td>
            <td align="center">7</td>
            <td align="center">1</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">5 Minutes Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLYwpaL_SFmcA1eJbqwvjKgsnT321hXRGx">High Performance Computing - Parallel Computing</a></td>
            <td align="center">38</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Computer Science and Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLJ5C_6qdAvBFMAko9JTyDJDIt1W48Sxmg">Introduction to parallel Programming in Open MP</a></td>
            <td align="center">37</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Carnegie Mellon Computer Architecture</td>
            <td><a href="https://youtube.com/playlist?list=PL5PHm2jkkXmh4cDkC3s1VBB7-njlgiG5d">Fall 2012 - 742 Parallel Computer Architecture</a></td>
            <td align="center">24</td>
            <td align="center">40</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">OpenMP</td>
            <td><a href="https://youtube.com/playlist?list=PLLX-Q6B8xqZ8n8bwjGdzBJ25X2utwnoEG">Introduction to OpenMP - Tim Mattson (Intel)</a></td>
            <td align="center">27</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">cscsch</td>
            <td><a href="https://youtube.com/playlist?list=PL1tk5lGm7zvQ-EzsiTZ6Xv1SxZs74epzg">High-Performance Computing with Python</a></td>
            <td align="center">15</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">CoffeeBeforeArch</td>
            <td><a href="https://youtube.com/playlist?list=PLxNPSjHT5qvugVNYwtQwnvSQyvlbzAML3">Practical Parallelism in C++</a></td>
            <td align="center">11</td>
            <td align="center">3</td>
        </tr>
    </tbody>
    </table>
