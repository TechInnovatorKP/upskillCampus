<img align="right" width="100" src="/logos/youtube.png"></img>

## Theory of Computations and Compiler Design Playlists

<h3>-  Theory of Computation</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PLbMVogVj5nJSd25WnSU144ZyGmsqjuKr3">Computer Science - Theory of Computation</a></td>
            <td align="center">42</td>
            <td align="center">45</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Neso Academy</td>
            <td><a href="https://youtube.com/playlist?list=PLBlnK6fEyqRgp46KUv4ZY69yXmpwKOIev">Theory of Computation & Automata Theory</a></td>
            <td align="center">114</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Lectures by Ravindrababu Ravula</td>
            <td><a href="https://youtube.com/playlist?list=PLEbnTDJUr_IdM___FmDFBJBz0zCsOFxfK">Theory of Computation or Automata Theory</a></td>
            <td align="center">72</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">KNOWLEDGE GATE</td>
            <td><a href="https://youtube.com/playlist?list=PLmXKhU9FNesSdCsn6YQqu9DmXRMsYdZ2T">7 – TOC | HINDI | TOFL | AUTOMATA | THEORY OF COMPUTATION</a></td>
            <td align="center">105</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Easy Engineering Classes</td>
            <td><a href="https://youtube.com/playlist?list=PLV8vIYTIdSnZYVUJ6duL_ulTsmVQmmd74">TOC in Hindi</a></td>
            <td align="center">47</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Education 4u</td>
            <td><a href="https://youtube.com/playlist?list=PLrjkTql3jnm_TWSXXvWX1_jX-L6f1QJSx">Theory of Computation ( TOC )</a></td>
            <td align="center">96</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Smashers</td>
            <td><a href="https://youtube.com/playlist?list=PLxCzCOWd7aiFM9Lj5G9G_76adtyb4ef7i">TOC(Theory of Computation)</a></td>
            <td align="center">56</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Well Academy</td>
            <td><a href="https://youtube.com/playlist?list=PL9zFgBale5ftkr9FLajMBN2R4jlEM_hxY">Theory of Computation GATE Lectures</a></td>
            <td align="center">67</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">5 Minutes Engineering</td>
            <td><a href="https://youtube.com/playlist?list=PLYwpaL_SFmcDXLUrW3JEq2cv8efNF6UeQ">Theory Of Computation (TOC)</a></td>
            <td align="center">23</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">DigiiMento: GATE, NTA NET & Other CSE Exam Prep</td>
            <td><a href="https://youtube.com/playlist?list=PLS8ACsmFCpmQ7aMtE2tG9mhYYor0BQ-Hn">Theory of Computation</a></td>
            <td align="center">43</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unacademy Computer Science</td>
            <td><a href="https://youtube.com/playlist?list=PLG9aCp4uE-s1P6Z73Gbbh-kdDWwq5Bg7f">Theory Of Computation (TOC) | GATE/ESE CSE & IT Engineering</a></td>
            <td align="center">63</td>
            <td align="center">65</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Instructors</td>
            <td><a href="https://youtube.com/playlist?list=PLXVjll7-2kRnUeE2TSBGlaGbm4aNIcZLJ">DFA NFA Examples | Problems Solution Tutorial | Automata Theory or Theory of computation</a></td>
            <td align="center">43</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">NTA UGC NET Computer Science CSE</td>
            <td><a href="https://youtube.com/playlist?list=PLayxKQoyjT383MJ2A2TGNlALVGnr5VPgh">Theory of computation</a></td>
            <td align="center">20</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">UC Davis</td>
            <td><a href="https://youtube.com/playlist?list=PLslgisHe5tBM8UTCt1f66oMkpmjCblzkt">Theory of Computation - Fall 2011</a></td>
            <td align="center">22</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Purple Hat Institute</td>
            <td><a href="https://youtube.com/playlist?list=PLNUrArhKbyAJ_s3NYwgNF8aNH254jHEvK">TOC: Theory Of Computation</a></td>
            <td align="center">17</td>
            <td align="center">3</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">CSE GURUS</td>
            <td><a href="https://youtube.com/playlist?list=PLYT7YDstBQmHSRKrNApTqquo2FRlMsoHw">FORMAL LANGUAGES AND AUTOMATA THEORY</a></td>
            <td align="center">42</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">hhp3</td>
            <td><a href="https://youtube.com/playlist?list=PLbtzT1TYeoMjNOGEiaRmm_vMIwUAidnQz">Theory of Computation</a></td>
            <td align="center">65</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Coderisland</td>
            <td><a href="https://youtube.com/playlist?list=PL601FC994BDD963E4">Introduction to the Theory of Computation</a></td>
            <td align="center">128</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Xoviabcs</td>
            <td><a href="https://youtube.com/playlist?list=PLEJxKK7AcSEEYrMd4G7Y3mjGlE651B7yc">Theory of Computation (TOC) or Automata Theory | Gate Lectures</a></td>
            <td align="center">32</td>
            <td align="center">20</td>
        </tr>
    </tbody>
</table>

<h3>-  Concepts of Programming Languages</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PLF7C73918190889CE">Computer Sc - Principles of Programming Languages</a></td>
            <td align="center">40</td>
            <td align="center">35</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">University Academy</td>
            <td><a href="https://youtube.com/playlist?list=PL-JvKqQx2AtdIkEFDrqsHyKWzb5PWniI1">Principle of Programming Language</a></td>
            <td align="center">18</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unknown</td>
            <td><a href="https://youtube.com/playlist?list=PLTo1TmBz2ekof8VsYaoTxP-9VgJ9P-dTO">Principles of Programming Languages</a></td>
            <td align="center">25</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unknown</td>
            <td><a href="https://youtube.com/playlist?list=PLb__S-rkKhexdiJomXSGeqQ46c_MUTPaj">Fundamentals of Programming Languages</a></td>
            <td align="center">20</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unknown</td>
            <td><a href="https://youtube.com/playlist?list=PLbWkMgLvWbDF3bErg6Ejo8d1QtTSqtWwN">Principles of Programming Languages</a></td>
            <td align="center">15</td>
            <td align="center">3</td>
        </tr>
    </tbody>
    </table>

<h3>-  Compilers</h3>
<table>
    <thead>
        <tr>
<th width="30%">Channel</th>
<th width="70%">Playlist</th>
<th>Videos</th>
<th>H</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan=1 align="center">Gate Lectures by Ravindrababu Ravula</td>
            <td><a href="https://youtube.com/playlist?list=PLEbnTDJUr_IcPtUXFy2b1sGRPsLFMghhS">Compiler Design</a></td>
            <td align="center">20</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PLbMVogVj5nJQNjkHZgwuAlfQ9tzmQDxjA">Computer Science - Principles of Compiler Design</a></td>
            <td align="center">40</td>
            <td align="center">40</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PLbMVogVj5nJTmKzaSlCpGgi7qxgcRRs8h">Computer Science - Compiler Design</a></td>
            <td align="center">30</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Tutorials Point (India) Ltd.</td>
            <td><a href="https://youtube.com/playlist?list=PLWPirh4EWFpGa0qAEcNGJo2HSRC5_KMT6">Compiler Design</a></td>
            <td align="center">106</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">nptelhrd</td>
            <td><a href="https://youtube.com/playlist?list=PL3690D679B876DE6A">Computer Science - Compiler Design</a></td>
            <td align="center">40</td>
            <td align="center">40</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Education 4u</td>
            <td><a href="https://youtube.com/playlist?list=PLrjkTql3jnm-wW5XdvumCa1u9LjczipjA">Compiler Design</a></td>
            <td align="center">58</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Smashers</td>
            <td><a href="https://youtube.com/playlist?list=PLxCzCOWd7aiEKtKSIHYusizkESC42diyc">Compiler Design (Complete Playlist)</a></td>
            <td align="center">31</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Anisul Islam</td>
            <td><a href="https://youtube.com/playlist?list=PLgH5QX0i9K3oWTwTgILA7v9oysoDgkJDg">Compiler Design Bangla Tutorials</a></td>
            <td align="center">24</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gradeup- GATE, ESE, PSUs Exam Preparation</td>
            <td><a href="https://youtube.com/playlist?list=PLynLXReWAxdGn85HptGs0Qz_esWIItC5s">All Compiler Design GATE Lectures</a></td>
            <td align="center">22</td>
            <td align="center">25</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Gate Instructors</td>
            <td><a href="https://youtube.com/playlist?list=PLXVjll7-2kRmpnXxL5QIZBZdRQys6ZHZC">Compiler Design Video Lecture for GATE Preparation</a></td>
            <td align="center">74</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unacademy Computer Science</td>
            <td><a href="https://youtube.com/playlist?list=PLG9aCp4uE-s3XepZyd94jGic7qMFa7CW1">Compiler Design</a></td>
            <td align="center">54</td>
            <td align="center">10</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">University Academy</td>
            <td><a href="https://youtube.com/playlist?list=PL-JvKqQx2Ate5DWhppx-MUOtGNA4S3spT">Compiler Design Tutorial In Hindi</a></td>
            <td align="center">56</td>
            <td align="center">20</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">itechnica</td>
            <td><a href="https://youtube.com/playlist?list=PL6aFkLM6Wp-rYWlSJGmOtex694M3UvG4F">Compiler Design</a></td>
            <td align="center">68</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Mifta Sintaha</td>
            <td><a href="https://youtube.com/playlist?list=PLW1OMpQZxu7xMh7nuDQYQ2mDcqY2hzBWk">Compiler Design</a></td>
            <td align="center">10</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">asha khilrani</td>
            <td><a href="https://youtube.com/playlist?list=PLz8TdOA7NTzSu-ePbGtghroiomWA-FFK9">Compiler Design lectures</a></td>
            <td align="center">72</td>
            <td align="center">15</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">LearnVidFun</td>
            <td><a href="https://youtube.com/playlist?list=PLwmA1T37CsHr_pTn20OACOesqRHdMjq-b">Compiler Design Tutorials</a></td>
            <td align="center">11</td>
            <td align="center">5</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unknown</td>
            <td><a href="https://youtube.com/playlist?list=PLRAdsfhKI4OWNOSfS7EUu5GRAVmze1t2y">Building a Compiler</a></td>
            <td align="center">28</td>
            <td align="center">60</td>
        </tr>
        <tr>
            <td rowspan=1 align="center">Unknown</td>
            <td><a href="https://youtube.com/playlist?list=PL6KMWPQP_DM97Hh0PYNgJord-sANFTI3i">Compilers</a></td>
            <td align="center">46</td>
            <td align="center">30</td>
        </tr>
    </tbody>
    </table>
